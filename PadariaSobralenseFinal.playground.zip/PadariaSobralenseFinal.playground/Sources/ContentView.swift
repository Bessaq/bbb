import SwiftUI

public struct ContentView: View {
    @StateObject private var cartVM = CartViewModel()
    public init() {}

    @ViewBuilder
    public var body: some View {
        TabView {
            NavigationView { HomeView() }
                .tabItem { Label("home", systemImage: "house") }

            NavigationView { FavoritesView() }
                .tabItem { Label("favoritos", systemImage: "heart") }

            NavigationView { CartView() }
                .tabItem {
                    Label("carrinho", systemImage: "cart")
                        .badge(cartVM.count)
                }

            NavigationView { OrdersView() }
                .tabItem { Label("pedidos", systemImage: "list.bullet.clipboard") }

            NavigationView { ProfileView() }
                .tabItem { Label("perfil", systemImage: "person") }
        }
        .environmentObject(cartVM)
    }
}
