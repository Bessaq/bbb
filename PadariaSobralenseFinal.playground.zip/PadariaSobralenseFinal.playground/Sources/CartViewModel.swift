import Foundation
import Combine

@MainActor
public final class CartViewModel: ObservableObject {
    @Published public private(set) var items: [Product] = []

    public var total: Double { items.reduce(0) { $0 + $1.price } }
    public var count: Int  { items.count }

    public init() {}

    public func add(_ product: Product) {
        items.append(product)
    }

    public func remove(_ product: Product) {
        items.removeAll { $0 == product }
    }

    public func clear() {
        items.removeAll()
    }
}
