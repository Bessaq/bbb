import SwiftUI

struct OrdersView: View {
    @State private var orders: [Order] = [
        .init(id: 1234, items: SampleData.products, total: 64.80,
              date: Date().addingTimeInterval(-60*60*24*61), status: .delivered),
        .init(id: 1235, items: [SampleData.products[1]], total: 39.90,
              date: Date().addingTimeInterval(-1400), status: .preparing)
    ]

    var body: some View {
        List(orders) { order in
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("Pedido #\(order.id)").bold()
                    Spacer()
                    StatusPill(status: order.status)
                }
                Text("\(order.items.count) itens • \(order.total, format: .currency(code: "BRL"))")
                Text(order.date, style: .relative)
                    .font(.caption).foregroundColor(.secondary)
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 16)
                .fill(Color("Card", bundle: nil, fallback: Color(.systemBackground)))
                .shadow(radius: 2))
        }
        .listStyle(.plain)
        .navigationTitle("Meus Pedidos")
    }
}

private struct StatusPill: View {
    let status: OrderStatus
    var body: some View {
        Text(status.rawValue)
            .font(.caption).bold().padding(.horizontal, 8).padding(.vertical, 4)
            .background(statusColor.opacity(0.2))
            .foregroundColor(statusColor)
            .clipShape(Capsule())
    }
    private var statusColor: Color {
        switch status {
        case .preparing: .yellow
        case .delivering: .blue
        case .delivered: .green
        }
    }
}
