import SwiftUI

struct CartView: View {
    @EnvironmentObject private var cartVM: CartViewModel

    var body: some View {
        List {
            ForEach(cartVM.items) { product in
                HStack {
                    AsyncImage(url: product.imageURL) { $0.resizable() } placeholder: {
                        Color.gray.opacity(0.3).shimmering()
                    }
                    .frame(width: 56, height: 56)
                    .clipShape(RoundedRectangle(cornerRadius: 8))

                    VStack(alignment: .leading) {
                        Text(product.name).font(.body)
                        Text(product.price, format: .currency(code: "BRL"))
                            .bold().foregroundColor(.green)
                    }
                    Spacer()
                    Button(role: .destructive) {
                        cartVM.remove(product)
                    } label: { Image(systemName: "xmark") }
                }
            }

            HStack {
                Text("Total:").bold()
                Spacer()
                Text(cartVM.total, format: .currency(code: "BRL"))
                    .bold().foregroundColor(.green)
            }

            Button("Finalizar Pedido") {
                // TODO: integracao pagamento
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.green)
            .foregroundColor(.white)
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .navigationTitle("Carrinho")
    }
}
