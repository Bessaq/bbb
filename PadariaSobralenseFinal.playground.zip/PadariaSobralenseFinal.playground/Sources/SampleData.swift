import Foundation

enum SampleData {
    static let categories: [Category] = [
        .init(name: "Mercado",  systemImage: "basket"),
        .init(name: "Salgados", systemImage: "takeoutbag.and.cup.and.straw"),
        .init(name: "Doces",    systemImage: "cupcake"),
        .init(name: "Bolos",    systemImage: "birthday.cake")
    ]

    static let products: [Product] = [
        .init(
            name: "Hambúrguer duplo à moda da casa",
            price: 24.90,
            imageURL: URL(string: "https://images.unsplash.com/photo-1534791547702-9b9971b2b3b1?auto=format&fit=crop&w=600&q=60")!,
            isPromo: false,
            promoLabel: nil,
            rating: 4.6
        ),
        .init(
            name: "Bolo com gotas de chocolate",
            price: 39.90,
            imageURL: URL(string: "https://images.unsplash.com/photo-1609790617630-d1e26be82b3a?auto=format&fit=crop&w=600&q=60")!,
            isPromo: true,
            promoLabel: "50% OFF",
            rating: 4.8
        )
    ]
}
