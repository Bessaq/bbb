import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var cartVM: CartViewModel
    @State private var showMiniCart = false

    private let grid = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        ScrollView {
            // Categories horizontal
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(SampleData.categories) { cat in
                        VStack {
                            Image(systemName: cat.systemImage)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .padding(12)
                                .background(RoundedRectangle(cornerRadius: 16)
                                    .stroke(Color.secondary.opacity(0.2)))
                            Text(cat.name).font(.footnote)
                        }
                    }
                }.padding(.horizontal)
            }

            // Banner promo
            ZStack(alignment: .leading) {
                LinearGradient(colors: [.gray.opacity(0.9), .gray.opacity(0.4)],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                VStack(alignment: .leading, spacing: 8) {
                    Text("Sua ceia descomplicada")
                        .font(.title2).bold().foregroundColor(.white)
                    Text("Asse seu peru na Padaria Sobralense e receba em até duas horas")
                        .foregroundColor(.white)
                        .font(.callout)
                    Button("Saiba mais!") {}.buttonStyle(.borderedProminent)
                }
                .padding()
            }
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .padding()

            // Sections
            SectionHeader(title: "Mais pedidos")
            LazyVGrid(columns: grid, spacing: 16) {
                ForEach(SampleData.products) { product in
                    ProductCard(product: product)
                }
            }.padding(.horizontal)

            SectionHeader(title: "Mais ofertas")
            LazyVGrid(columns: grid, spacing: 16) {
                ForEach(SampleData.products.filter { $0.isPromo }) { product in
                    ProductCard(product: product, promo: true)
                }
            }.padding(.horizontal)
        }
        .navigationTitle("Padaria")
        .toolbar {
            Button {
                showMiniCart = true
            } label: {
                CartToolbarItem(count: cartVM.count)
            }
        }
        .sheet(isPresented: $showMiniCart) {
            MiniCartSheet()
                .presentationDetents([.height(320)])
                .presentationDragIndicator(.visible)
        }
    }
}

// Helper subviews
private struct SectionHeader: View {
    let title: String
    var body: some View {
        HStack { Text(title).font(.title2).bold(); Spacer() }
            .padding(.horizontal)
    }
}

private struct ProductCard: View {
    @EnvironmentObject private var cartVM: CartViewModel
    let product: Product
    var promo = false

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            AsyncImage(url: product.imageURL) { phase in
                switch phase {
                case .empty:
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.gray.opacity(0.2))
                        .shimmering()
                        .frame(height: 120)
                case .success(let img):
                    img.resizable().scaledToFill()
                        .frame(height: 120).clipped()
                default:
                    Color.red.frame(height: 120)
                }
            }
            .overlay(
                promo && product.promoLabel != nil ?
                    Text(product.promoLabel!)
                        .font(.caption2).bold().padding(6)
                        .background(Color.yellow)
                        .clipShape(Capsule()).padding(6)
                : nil,
                alignment: .bottomLeading
            )

            Text(product.name).font(.footnote).lineLimit(2)
            Text(product.price, format: .currency(code: "BRL"))
                .font(.callout).bold().foregroundColor(.green)
        }
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color("Card", bundle: nil, fallback: Color(.systemBackground)))
                .shadow(radius: 4)
        )
        .onTapGesture { cartVM.add(product) }
    }
}

private struct CartToolbarItem: View {
    let count: Int
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Image(systemName: "cart")
            if count > 0 {
                Text("\(count)")
                    .font(.caption2).bold()
                    .frame(width: 16, height: 16)
                    .background(Color.red).foregroundColor(.white)
                    .clipShape(Circle())
                    .offset(x: 6, y: -6)
            }
        }
    }
}
