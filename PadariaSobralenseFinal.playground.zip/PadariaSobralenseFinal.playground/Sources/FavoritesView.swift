import SwiftUI

struct FavoritesView: View {
    @EnvironmentObject private var cartVM: CartViewModel
    @State private var favorites: [Product] = SampleData.products

    var body: some View {
        List {
            ForEach(favorites) { product in
                HStack {
                    AsyncImage(url: product.imageURL) { phase in
                        switch phase {
                        case .empty:
                            Color.gray.opacity(0.3).shimmering()
                        case .success(let img):
                            img.resizable()
                        default:
                            Color.red
                        }
                    }
                    .frame(width: 56, height: 56)
                    .clipShape(RoundedRectangle(cornerRadius: 8))

                    VStack(alignment: .leading) {
                        Text(product.name).font(.body)
                        Text(product.price, format: .currency(code: "BRL"))
                            .bold().foregroundColor(.green)
                        Label("\(product.rating, specifier: "%.1f")", systemImage: "star.fill")
                            .font(.caption).foregroundColor(.yellow)
                    }
                    Spacer()
                    Button { cartVM.add(product) } label: {
                        Image(systemName: "plus").padding(12)
                            .background(Color.green).foregroundColor(.white)
                            .clipShape(Circle())
                    }
                }
            }
        }
        .navigationTitle("Seus Favoritos")
    }
}
