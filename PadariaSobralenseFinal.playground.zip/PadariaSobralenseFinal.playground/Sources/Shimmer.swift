import SwiftUI

struct Shimmer: ViewModifier {
    @State private var phase: CGFloat = -200
    func body(content: Content) -> some View {
        content
            .overlay(
                LinearGradient(
                    gradient: Gradient(colors: [.clear, Color.white.opacity(0.4), .clear]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing)
                .offset(x: phase)
            )
            .onAppear {
                withAnimation(.linear(duration: 1.2).repeatForever(autoreverses: false)) {
                    phase = 600
                }
            }
    }
}
extension View {
    func shimmering() -> some View { self.modifier(Shimmer()) }
}
