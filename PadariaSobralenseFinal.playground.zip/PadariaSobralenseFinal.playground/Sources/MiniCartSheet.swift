import SwiftUI

struct MiniCartSheet: View {
    @EnvironmentObject private var cartVM: CartViewModel

    var body: some View {
        VStack(spacing: 8) {
            Text("Seu carrinho").font(.headline)
            List {
                ForEach(cartVM.items) { p in
                    HStack {
                        AsyncImage(url: p.imageURL) { image in
                            image.resizable()
                        } placeholder: {
                            Color.gray.opacity(0.3)
                        }
                        .frame(width: 40, height: 40)
                        .clipShape(RoundedRectangle(cornerRadius: 6))

                        Text(p.name).font(.caption)
                        Spacer()
                        Text(p.price, format: .currency(code: "BRL"))
                    }
                }
            }
            .frame(maxHeight: 180)
            Text("Subtotal: \(cartVM.total, format: .currency(code: "BRL"))")
                .bold()
            Button("Finalizar Pedido") {
                // integração futura
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}
