import Foundation

public enum OrderStatus: String, Codable {
    case preparing   = "Em preparo"
    case delivering  = "Saiu para entrega"
    case delivered   = "Entregue"
}

public struct Order: Identifiable, Codable {
    public let id: Int
    public let items: [Product]
    public let total: Double
    public let date: Date
    public var status: OrderStatus
}
