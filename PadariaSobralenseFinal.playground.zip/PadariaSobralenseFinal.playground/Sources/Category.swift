import Foundation

public struct Category: Identifiable, Hashable {
    public let id = UUID()
    public let name: String
    public let systemImage: String
}
