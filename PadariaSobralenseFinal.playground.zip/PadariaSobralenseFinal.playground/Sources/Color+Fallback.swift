import SwiftUI

extension Color {
    init(_ name: String, bundle: Bundle? = nil, fallback: Color) {
        self = Color(name, bundle: bundle)
        if self == Color(name) { // Asset not found returns default (same name)
            self = fallback
        }
    }
}
