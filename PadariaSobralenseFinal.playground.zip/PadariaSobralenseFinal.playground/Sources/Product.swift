import Foundation

public struct Product: Identifiable, Hashable, Codable {
    public let id = UUID()
    public let name: String
    public let price: Double
    public let imageURL: URL
    public let isPromo: Bool
    public let promoLabel: String?
    public let rating: Double
}
