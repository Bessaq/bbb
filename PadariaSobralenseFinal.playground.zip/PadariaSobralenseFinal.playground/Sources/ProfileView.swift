import SwiftUI

struct ProfileView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                VStack {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable().scaledToFit()
                        .frame(width: 96, height: 96)
                        .foregroundColor(.white)
                        .background(Circle().fill(Color.green))
                    Text("João Silva").font(.title3).bold()
                    Text("joao.silva@email.com").foregroundColor(.secondary)
                }.padding(.top)

                GroupBox("Configurações da Conta") {
                    SettingsRow(title: "Editar Perfil")
                    SettingsRow(title: "Endereços")
                    SettingsRow(title: "Métodos de Pagamento")
                    SettingsRow(title: "Notificações")
                }
                GroupBox("Suporte") {
                    SettingsRow(title: "Central de Ajuda")
                    SettingsRow(title: "Fale Conosco")
                    SettingsRow(title: "Sobre o App")
                }
            }
            .padding()
        }
        .navigationTitle("Perfil")
    }
}

private struct SettingsRow: View {
    let title: String
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Image(systemName: "chevron.right").foregroundColor(.secondary)
        }
        .padding(.vertical, 8)
    }
}
