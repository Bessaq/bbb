import SwiftUI
import PlaygroundSupport

PlaygroundPage.current.setLiveView(ContentView())
